from setuptools import setup

setup(
    name='modules',
    version='0.0.1',
    description='maize-project modules',
    license='MIT',
    packages=['modules'],
    author='Max Hargreaves',
    author_email='whargrea@uoguelph.ca',
    keywords=['na'],
    url='https://github.com/DiDeoxy/maize-project'
)